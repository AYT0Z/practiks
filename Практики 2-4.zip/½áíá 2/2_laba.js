var counter = 0
var riddleflag = 0
var answerFlag

const riddleNumber = document.getElementById('riddleNum')
const riddleQuestion = document.getElementById('riddleQuest')
const firstAns = document.getElementById('fAnswer')
const secondAns = document.getElementById('sAnswer')

function qvizStart() {
    document.getElementById('qvizHTML').style.display = 'block'
}
function answer() {

    if (answerFlag == 1) {
        alert('Правильный ответ')
        counter++;
        document.getElementById('score').innerHTML = counter;
    } else {
        alert('Ответ неверный')
    }

    riddleflag++;

    if (riddleflag == 1) { secondRiddle() }

    if (riddleflag == 2) {
        alert("Итоговые отгадки: " + counter)
        qvizClose()
    }
}

function secondRiddle() {
    answerFlag = 0;
    riddleNumber.innerHTML = 'Вторая загадка'
    riddleQuestion.innerHTML = 'Какого цвета вода?'
    firstAns.innerHTML = 'Прозрачная'
    secondAns.innerHTML = 'Синяя'

}
function qvizClose() {
    document.getElementById('qvizHTML').style.display = 'none'

    counter = 0;
    riddleflag = 0;

    document.getElementById('score').innerHTML = counter;

    riddleNumber.innerHTML = 'Первая загадка'
    riddleQuestion.innerHTML = 'На какой реке построен город Москва'
    firstAns.innerHTML = 'Москва'
    secondAns.innerHTML = 'Волга'
}

function drunk() {
    var more = prompt('Еще по одной?')
    if (more == 1) {
        alert('Доброй дороги путник')
    } else { drunk() }
}
function factorialbtn() {
    var n = parseInt(prompt('Введите номер в журнале:'))

    function factorial() {
        var result = 1;
        for (var i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
    alert('Факториал по вашему номеру:' + factorial())
}

function polindr() {
    var lastname = prompt('Введите вашу фамилию').toLowerCase()
    var antilastname = lastname.split("").reverse().join("")
    // console.log(antilastname)
    if (lastname == antilastname) {
        alert('Фамилия палиндром')
    } else {
        alert('Фамилия не палиндром')
    }

}

function simplenumber() {
    var a = parseInt(prompt('Введите ваш номер в журнале'))
    // console.log(a)
    var arr = [1];
    function simplecheck(num) {
        for (var i = 2; i < num; i++) {
            if (num % i === 0) return false;
        }
        return num !== 1;
    }

    function printPrimes(a) {
        for (let i = 2; i <= a; i++) {
            if (simplecheck(i)) arr[arr.length] = i;
        }
    }
    printPrimes(a)
    alert(arr)
}
