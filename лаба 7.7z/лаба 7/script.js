
function task1() {
    let id = Symbol("id")
    const bank_client = {
        [id]: 0,
        name: 'Andrey',
        score: 1000,
    }
    const clinic_worker = {
        [id]: 0,
        name: 'Gabiel',
        spec: 'Surgeon',
    }
    const сitizen = {
        [id]: 0,
        name: 'Vasya',
        age: 18,
    }
    alert('id: ' + bank_client[id] + ', name: ' + bank_client.name + ', score: ' + bank_client.score)
}
function task2() {
    const number = +prompt('Загадайте цифру до 9', '');

    switch (number) {
        case 1:
            alert('Вы ввели число 1');
            break;
        case 2:
            alert('Вы ввели число 2');
            break;
        case 3:
            alert('Вы ввели число 3');
            break;
        case 4:
            alert('Вы ввели число 4');
            break;
        case 5:
            alert('Вы ввели число 5');
            break;
        case 6:
            alert('Вы ввели число 6');
            break;
        case 7:
            alert('Вы ввели число 7');
            break;
        case 8:
        case 9:
            alert('Вы ввели число 8, а может и 9');
            break;

        default:
            alert('Вы ввели че-то не то')

    }

}
function task3() {
    const min = +prompt('Введи число от 0 до 59')

    switch (min) {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 10:
        case 11:
        case 12:
        case 13:
        case 14:
            alert('Число попадает в первую четверть часа');
            break;
        case 15:
        case 16:
        case 17:
        case 18:
        case 19:
        case 20:
        case 21:
        case 22:
        case 23:
        case 24:
        case 25:
        case 26:
        case 27:
        case 28:
        case 29:
            alert('Число попадает во вторую четверть часа');
            break;
        case 30:
        case 31:
        case 32:
        case 33:
        case 34:
        case 35:
        case 36:
        case 37:
        case 38:
        case 39:
        case 40:
        case 41:
        case 42:
        case 43:
        case 44:
            alert('Число попадает в третью четверть часа');
            break;
        case 45:
        case 46:
        case 47:
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:
        case 58:
        case 59:
            alert('Число попадает в четвертую четверть часа');
            break;
    }
}
function task4() {
    let numberstr = prompt('Введите строку с цифрами:')
    numberstr = numberstr.split('')
    console.log(numberstr)



    switch (numberstr[0]) {
        case '1':
            alert('Строка начинается с 1');
            break;
        case '2':
            alert('Строка начинается с 2');
            break;
        case '3':
            alert('Строка начинается с 3');
            break;
    }
}