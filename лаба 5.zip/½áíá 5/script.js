function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

let arr = [];
let spawn = (n) => {
    for (let i = 0; i < n; i++) {
        arr[i] = getRandomInt(3)
    }
    return arr
}

let check = (arr) => {
    var redmax = 0;
    var currredmax = 0;
    var blackmax = 0;
    var currblackmax = 0;
    var whitemax = 0;
    var currwhitemax = 0;
    for (var i = 0; i < arr.length; i++) {

        if (arr[i] === 0) {
            redmax++
        } else {
            if (redmax > currredmax) {
                currredmax = redmax
            }
            redmax = 0
        }

        if (arr[i] === 1) {
            blackmax++
        } else {
            if (blackmax > currblackmax) {
                currblackmax = blackmax
            }
            blackmax = 0
        }

        if (arr[i] === 2) {
            whitemax++
        } else {
            if (whitemax > currwhitemax) {
                currwhitemax = whitemax
            }
            whitemax = 0
        }

    }
    if (currredmax > currwhitemax && currredmax > currblackmax) {
        alert('Наибольшая последовательность состоит из красных шариков: ' + currredmax)
    } else if (currwhitemax > currblackmax) {
        alert('Наибольшая последовательность состоит из белых шариков: ' + currwhitemax)
    } else alert('Наибольшая последовательность состоит из черных шариков: ' + currblackmax)
}
spawn(1000000)
check(arr)
// console.log(arr)